Ini Adalah Program  expanded layout adapun screenshot hasil run nya adalah sebagai berikut:
![WhatsApp Image 2023-11-10 at 17 05 04](https://github.com/AiDinaAgustin/expanded/assets/95268109/8fcb3d9d-068a-44f2-b17a-caf8641f6a8e)
